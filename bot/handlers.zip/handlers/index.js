async function handleMessage(sock, db, from, mensaje) {
  console.log("Mensaje:", mensaje);

  await sock.sendMessage(from, {
    text: "Recibido: " + mensaje
  });
}

module.exports = { handleMessage };