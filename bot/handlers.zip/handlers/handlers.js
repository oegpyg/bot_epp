const axios = require('axios');

// =========================
// ESTADOS
// =========================
const usuariosEnRegistro = {};
const usuariosAfiliado = {};

// =========================
// MENÚ
// =========================
function menu(sock, from) {
  return sock.sendMessage(from, {
    text: `👋 Hola
Bienvenido al equipo de Renzo Benítez 🇵🇾

1️⃣ Propuestas
2️⃣ Sumarme al Equipo
3️⃣ Recorrido Semanal
4️⃣ Carga de Planillas
5️⃣ Redes Oficiales
6️⃣ Compartir Campaña
7️⃣ Simulador Renzo Benítez
8️⃣ Consulta Afiliados`
  });

};

// =========================
// PROPUESTAS
// =========================
function propuestas(sock, from) {
  return sock.sendMessage(from, {

    text: `📌 Propuestas:
- Seguridad
- Empleo
- Juventud`
  });
}

// =========================
// VOLUNTARIOS
// =========================
async function voluntarios(sock, db, from, text) {

  if (!usuariosEnRegistro[from]) {
    usuariosEnRegistro[from] = { tipo: 'voluntario', paso: 1 };
    return sock.sendMessage(from, { text: '🤝 Escribe tu nombre completo' });
  }

  const estado = usuariosEnRegistro[from];

  if (estado.paso === 1) {
    estado.nombre = text;
    estado.paso = 2;
    return sock.sendMessage(from, { text: '📱 Escribe tu contacto' });
  }

  if (estado.paso === 2) {
    return db.get(
      "SELECT * FROM voluntarios WHERE contacto = ?",
      [text],
      (err, row) => {

        if (row) {
          delete usuariosEnRegistro[from];
          return sock.sendMessage(from, { text: "⚠️ Ya estás registrado" });
        }

        db.run(
          `INSERT INTO voluntarios (nombre, contacto, fecha)
           VALUES (?, ?, datetime('now'))`,
          [estado.nombre, text],
          () => {
            delete usuariosEnRegistro[from];
            sock.sendMessage(from, { text: "✅ Voluntario registrado" });
          }
        );
      }
    );
  }
}

// =========================
// SIMPATIZANTES
// =========================
async function simpatizantes(sock, db, from, text) {

  if (!usuariosEnRegistro[from]) {
    usuariosEnRegistro[from] = { tipo: 'simpatizante', paso: 1 };
    return sock.sendMessage(from, { text: '✍️ Escribe tu nombre completo' });
  }

  const estado = usuariosEnRegistro[from];

  if (estado.paso === 1) {
    estado.nombre = text;
    estado.paso = 2;
    return sock.sendMessage(from, { text: '📍 Escribe tu barrio' });
  }

  if (estado.paso === 2) {
    estado.barrio = text;
    estado.paso = 3;
    return sock.sendMessage(from, { text: '📱 Escribe tu contacto' });
  }

  if (estado.paso === 3) {
    return db.get(
      "SELECT * FROM simpatizantes WHERE contacto = ?",
      [text],
      (err, row) => {

        if (row) {
          delete usuariosEnRegistro[from];
          return sock.sendMessage(from, { text: "⚠️ Ya registrado" });
        }

        db.run(
          `INSERT INTO simpatizantes (nombre, barrio, contacto, fecha)
           VALUES (?, ?, ?, datetime('now'))`,
          [estado.nombre, estado.barrio, text],
          () => {
            delete usuariosEnRegistro[from];
            sock.sendMessage(from, { text: "✅ Registrado" });
          }
        );
      }
    );
  }
}

// =========================
// AFILIACIÓN
// =========================
async function afiliacion(sock, from, text) {

  if (!usuariosAfiliado[from]) {
    usuariosAfiliado[from] = true;
    return sock.sendMessage(from, { text: '🔎 Ingresa tu cédula' });
  }

  usuariosAfiliado[from] = false;

  try {
    const res = await axios.get(
      `https://plra.org.py/public/buscar_padron.php?cedula=${text}`
    );

    const data = res.data;

    if (!Array.isArray(data) || data.length === 0) {
      return sock.sendMessage(from, { text: '❌ No encontrado' });
    }

    return sock.sendMessage(from, {
      text: `👤 ${data[0].nombresYApellido}`
    });

  } catch {
    return sock.sendMessage(from, { text: '⚠️ Error padrón' });
  }
}

// =========================
// HANDLER PRINCIPAL
// =========================
async function handleMessage(sock, db, from, text) {

  const msg = (text || '').toLowerCase().trim();

  if (msg === 'menu' || msg === 'hola') return menu(sock, from);
  if (msg === '1') return propuestas(sock, from);
  if (msg === '2') return simpatizantes(sock, db, from, text);
  if (msg === '3') return sock.sendMessage(from, { text: '📅 Evento semanal' });
  if (msg === '4') return voluntarios(sock, db, from, text);
  if (msg === '8') return afiliacion(sock, from, text);

  return sock.sendMessage(from, {
    text: 'Escribe *menu*'
  });
}

module.exports = { handleMessage };